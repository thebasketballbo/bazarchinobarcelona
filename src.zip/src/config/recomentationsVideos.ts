export const allPageVideos = ["/videos/video1.mp4", "/videos/video2.mp4", "/videos/video3.mp4", "/videos/video4.mp4", "/videos/video5.mp4", "/videos/video6.mp4"]
